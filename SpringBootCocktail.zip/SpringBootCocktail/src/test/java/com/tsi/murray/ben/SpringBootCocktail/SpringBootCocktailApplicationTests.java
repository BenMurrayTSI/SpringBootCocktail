package com.tsi.murray.ben.SpringBootCocktail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCocktailApplicationTests {

	@Test
	void contextLoads() {
	}

}
