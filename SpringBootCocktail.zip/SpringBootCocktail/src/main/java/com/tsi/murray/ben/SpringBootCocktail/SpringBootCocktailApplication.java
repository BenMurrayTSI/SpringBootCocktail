package com.tsi.murray.ben.SpringBootCocktail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCocktailApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCocktailApplication.class, args);
	}

}
